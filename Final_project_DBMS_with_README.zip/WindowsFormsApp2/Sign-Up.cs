﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Sign_Up : Form
    {
        SqlConnection con = new SqlConnection("Data Source = ROROS-LAPTOP; Initial Catalog = final_project; Integrated Security=True ");

        public Sign_Up()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

            login log = new login();
            log.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {

            Form3 log = new Form3();
            log.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

            login log = new login();
            log.ShowDialog();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert Into Users Values(@Name,@Pass)", con);
            cmd.Parameters.AddWithValue("@Name", textBox3.Text);
            cmd.Parameters.AddWithValue("@Pass", textBox1.Text);
            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Saved");
            con.Close();

        }

        private void button4_Click_1(object sender, EventArgs e)
        {

            login log = new login();
            log.ShowDialog();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
             this.WindowState = FormWindowState.Maximized;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Sign_Up_Load(object sender, EventArgs e)
        {
            textBox1.PasswordChar = '*';    
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
