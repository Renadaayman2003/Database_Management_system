﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class profattendance : Form
    {
        SqlConnection con = new SqlConnection("Data Source = ROROS-LAPTOP; Initial Catalog = final_project; Integrated Security=True ");
        public profattendance()
        {
            InitializeComponent();
        }
        void GetRenadaProfeeData()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Professor ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Insert Into Student_Attendance Values(@ID,@cid,@proname,@coursename,@room,@Date)", con);
            cmd.Parameters.AddWithValue("@ID", comboBox2.SelectedValue);
            cmd.Parameters.AddWithValue("@cid", comboBox3.SelectedValue);
            cmd.Parameters.AddWithValue("@proname", comboBox2.Text);
            cmd.Parameters.AddWithValue("@coursename", comboBox3.Text);
            cmd.Parameters.AddWithValue("@room", numericUpDown2.Value);
            cmd.Parameters.AddWithValue("@Date", dateTimePicker1.Value);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Saved");
            con.Close();
            GetRenadaProfeattData();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;   
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState=FormWindowState.Minimized;
        }
        void GetRenadaattendanceDataList()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Course", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBox3.DataSource = dt;    /// rag3 data kolaha w nafz statment l fo2 bt3t sql 
            comboBox3.DisplayMember = "Course_Name";    // display asm course 
            comboBox3.ValueMember = "Course_ID";    //khale ID lek f background msh hatshfoha
            con.Close();
        }
        void GetRenadaProfeeDataList()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Professor", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBox2.DataSource = dt;    /// rag3 data kolaha w nafz statment l fo2 bt3t sql 
            comboBox2.DisplayMember = "Prof_FirstName";    // display asm course 
            comboBox2.ValueMember = "Prof_ID";    //khale ID lek f background msh hatshfoha

            comboBox1.DataSource = dt;    /// rag3 data kolaha w nafz statment l fo2 bt3t sql 
            comboBox1.DisplayMember = "Prof_FirstName";    // display asm course 
            comboBox1.ValueMember = "Prof_ID";    //khale ID lek f background msh hatshfoha
            con.Close();
        }
        void GetRenadaProfeattData()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Student_Attendance ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }
        private void button2_Click(object sender, EventArgs e)
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Student_Attendance where Professor_ID=@Name", con);
            cmd.Parameters.AddWithValue("@Name", comboBox1.SelectedValue);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
            con.Close();
        }

        private void profattendance_Load(object sender, EventArgs e)
        {
            GetRenadaattendanceDataList();
            GetRenadaProfeeDataList();
            


        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }
    }
}
