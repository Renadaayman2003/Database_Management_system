﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Schedule : Form
    {
        SqlConnection con = new SqlConnection("Data Source = ROROS-LAPTOP; Initial Catalog = final_project; Integrated Security=True ");
        public Schedule()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Close(); //exit all aplication 
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
        void GetRenadacoursesDataList()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Course ", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBox1.DataSource = dt;    /// rag3 data kolaha w nafz statment l fo2 bt3t sql 
            comboBox1.DisplayMember = "Course_Name";    // display asm course 
            comboBox1.ValueMember = "Course_ID" ;    //khale ID lek f background msh hatshfoha
            con.Close();
        }
        void GetRenadastudentDataList()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBox2.DataSource = dt;    /// rag3 data kolaha w nafz statment l fo2 bt3t sql 
            comboBox2.DisplayMember = "Student_Name";    // display asm course 
            comboBox2.ValueMember = "Student_ID";    //khale ID lek f background msh hatshfoha
            con.Close();
        }
        void GetRenadaProfeeDataList()
        {
            con.Open();
            SqlCommand cmd = new SqlCommand("Select * from professor", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            comboBox2.DataSource = dt;    /// rag3 data kolaha w nafz statment l fo2 bt3t sql 
            comboBox2.DisplayMember = "Prof_FirstName";    // display asm course 
            comboBox2.ValueMember = "Prof_ID";    //khale ID lek f background msh hatshfoha
            con.Close();
        }
        private void button1_Click(object sender, EventArgs e)
        {

            con.Open();
            SqlCommand cmd = new SqlCommand("Insert Into  Schedule (Prof_TA_ID,Course_ID,Prof_TA_Name,Course_Name,Course_Date,Room_Number) Values (@stID,@Cid,@Pname,@Cname,@date,@roomn)", con);
            cmd.Parameters.AddWithValue("@stID", textBox9.Text);
            cmd.Parameters.AddWithValue("@Cid", comboBox2.SelectedValue);
            cmd.Parameters.AddWithValue("@Cname", comboBox2.Text);
            cmd.Parameters.AddWithValue("@Pname", comboBox1.Text);
            cmd.Parameters.AddWithValue("@roomn", numericUpDown1.Value);
            cmd.Parameters.AddWithValue("@date", dateTimePicker1.Value);

            cmd.ExecuteNonQuery();
            MessageBox.Show("Successfully Saved");
            con.Close();
            GetRenadaProfeeDataList();
        }

        private void Schedule_Load(object sender, EventArgs e)
        {
            GetRenadaProfeeDataList();
            GetRenadacoursesDataList();
            GetRenadastudentDataList();


        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
